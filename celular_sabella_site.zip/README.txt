
Site simulado do celular de Sabella Monroe (fictício) - pronto para deploy
Arquivos gerados em /mnt/data/celular_sabella_site

Como publicar (GitHub Pages):
1. Crie um repositório no GitHub.
2. Faça upload de toda a pasta 'celular_sabella_site' para o repositório (todos os arquivos e a pasta assets).
3. Vá em Settings > Pages e configure a branch 'main' e root '/' (ou docs/).
4. Após alguns minutos, seu site estará disponível em https://<usuario>.github.io/<reponame>/

Alternativa: faça upload direto no Netlify (arraste a pasta) e ele publicará um link.

Substitua os arquivos em assets/ por imagens e áudios reais que você gravar para aumentar imersão.
