
const chats = [
  {who:'Evelyn Reed', time:'21:12', text:'Sabella, precisamos conversar antes da coroação. É urgente.'},
  {who:'Sabella', time:'21:13', text:'Agora? No meio do baile? Não pode ser aqui.'},
  {who:'Harper Gray', time:'21:21', text:'Boa sorte esta noite. Espero que a coroa não pese demais.'},
  {who:'Liam Parker', time:'21:28', text:'Volta comigo. Só uma chance. Por favor.'},
  {who:'Sabella', time:'21:30', text:'Liam, hoje não. Eu mereço isso.'},
  {who:'Noah Evans', time:'22:05', text:'Tenho umas fotos que você precisa ver. Não mostro pra ninguém.'},
  {who:'Sabella', time:'22:08', text:'Traga aqui, vou ver nos bastidores.'},
  {who:'Unknown', time:'22:43', text:'(Mensagem apagada)'},
  {who:'Evelyn Reed', time:'22:47', text:'Encontrei uma carta. Ela disse pra procurar o armário 108.'},
  {who:'Sabella', time:'22:48', text:'NÃO ME DEIXEM SOZINHA.'},
  {who:'Harper Gray', time:'22:50', text:'Só o que ela merecia.'},
  {who:'Liam Parker', time:'22:51', text:'Não foi minha intenção...'},
  {who:'Noah Evans', time:'22:53', text:'A câmera caiu. Apaguei algumas fotos. Eu só queria proteger todo mundo.'},
  {who:'Mr. Collins', time:'23:05', text:'Ninguém deveria saber o que aconteceu nos bastidores.'},
  {who:'Police', time:'23:40', text:'Todos os presentes serão questionados. Ninguém deixa o local.'}
];

const photos = [
  {src:'assets/baile1.svg', alt:'Sabella coroada, sorriso forçado'},
  {src:'assets/baile2.svg', alt:'Foto borrada: sombra próxima ao palco'},
  {src:'assets/stage.svg', alt:'Palco vazio com cortina rasgada'},
  {src:'assets/closeup.svg', alt:'Copo com líquido rosado (marcado como evidência)'}
];

const calls = [
  {who:'Liam Parker', time:'22:05', type:'perda'},
  {who:'Noah Evans', time:'22:12', type:'recebida'},
  {who:'Unknown', time:'22:47', type:'perda'},
  {who:'Evelyn Reed', time:'22:49', type:'perda'}
];

const files = [
  {name:'diario_excerpt.txt', href:'assets/diario_excerpt.txt'},
  {name:'autopsia_resumo.txt', href:'assets/autopsia_resumo.txt'},
  {name:'audio_bastidores_placeholder.txt', href:'assets/audio_bastidores.txt'}
];

function openSection(id){
  document.querySelectorAll('.screen-section').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function render(){
  const chatList = document.getElementById('chatList');
  chats.forEach(c=>{
    const el = document.createElement('div'); el.className='msg';
    el.innerHTML = `<div class="who">${c.who}</div><div class="time">${c.time}</div><div class="text">${c.text}</div>`;
    chatList.appendChild(el);
  });

  const gallery = document.getElementById('gallery');
  photos.forEach(p=>{
    const img = document.createElement('img'); img.src = p.src; img.alt=p.alt;
    gallery.appendChild(img);
  });

  const callsList = document.getElementById('callsList');
  calls.forEach(c=>{
    const li=document.createElement('li'); li.textContent = `${c.time} - ${c.who} (${c.type})`;
    callsList.appendChild(li);
  });

  const filesList = document.getElementById('filesList');
  files.forEach(f=>{
    const li=document.createElement('li');
    li.innerHTML = `<a href="${f.href}" target="_blank" rel="noopener">${f.name}</a>`;
    filesList.appendChild(li);
  });
}

render();
